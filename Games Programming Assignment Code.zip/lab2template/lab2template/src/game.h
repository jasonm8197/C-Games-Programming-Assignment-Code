#pragma once
#include <SDL.h>
class Game
{
public:
	void RenderTile();
};