#pragma once
#include <map>
#include <vector>
#include <string>
#include <stdlib.h>
using namespace std;

//Utility class containing static functions

class Utils
{
public:
	
};